package com.ForCinema.LifeArchive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeArchiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
